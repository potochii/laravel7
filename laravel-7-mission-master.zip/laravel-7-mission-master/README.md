# Laravel 7 Mission

โจทย์อยู่ใน slide ด้านล่างนี้ คลิก เบาๆ แล้วไปกันเลย

(https://docs.google.com/presentation/d/13tJ08CjUUNxKMgLpvagjKtdrIx7jSdvDii5tcaeVwG4/edit?usp=sharing)[https://docs.google.com/presentation/d/13tJ08CjUUNxKMgLpvagjKtdrIx7jSdvDii5tcaeVwG4/edit?usp=sharing]

## วิธีการทำโจทย์

1. Clone code จาก repository ติดตั้งลงในเครื่อง
2. เมื่อติดตั้ง หรือ run ขึ้นมาได้แล้ว ให้เริ่มทำโจทย์ ในแต่ละ mission
3. ใน code เวอร์ชั่นปัจจุบันจะมีทั้ง bug ที่ผู้เขียนตั้งใจทิ้งไว้ และมีโจทย์ที่ให้ทำใหม่ feature เพิ่ม
4. เมื่อทำทุก mission เสร็จแล้ว ให้ สร้าง branch โดยใช้ชื่อภาษาอังฤษตัวพิมพ์เล็ก แล้วสร้าง Pull Request เอาไว้
5. ทางทีมจะเข้ามาตรวจสอบ และจะรีบส่งอีเมลเพื่อเรียกเข้ามาสัมภาษณ์คุณสมบัติ
