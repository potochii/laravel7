<?php $__env->startSection('content'); ?>

<?php
    $isCreate = Request::route()->getName() == 'topics.create';
?>

<div class="container">
    <div class="row mb-4">
        <div class="col-12">
            <?php if(session()->has('save_status')): ?>
            <div class="alert alert-<?php echo e(session()->get('save_status')['status']); ?>">
                <?php echo e(session()->get('save_status')['message']); ?>

            </div>
            <?php endif; ?>


            <form class="card" method="post" action="<?php echo e($isCreate ? route('topics.store') : route('topics.update', $topic->id ?? 0)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field($isCreate ? 'post' : 'put'); ?>
                <div class="card-header">
                    <h3 class="card-title"><?php echo e($isCreate ? 'Create' : 'Edit'); ?> topic</h3>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="topic">Title</label>
                        <input value="<?php echo e($topic->title ?? ''); ?>" class="form-control <?php echo e($errors->has('title') ? 'is-invalid' : ''); ?>" name="title"></input>
                        <span class="invalid-feedback"><?php echo e($errors->first('title')); ?></span>
                    </div>
                    <div class="form-group">
                        <label for="content">Content</label>
                        <textarea name="content" id="content" class="form-control <?php echo e($errors->has('content') ? 'is-invalid' : ''); ?>" cols="30" rows="10"><?php echo e($topic->content ?? ''); ?></textarea>
                        <span class="invalid-feedback"><?php echo e($errors->first('content')); ?></span>
                    </div>
                </div>
                <div class="card-footer">
                    <button class="btn btn-success"><?php echo e($isCreate ? 'New' : 'Update'); ?> topic</button>
                </div>
            </form>



        </div>
    </div>

    <?php if(!$isCreate): ?>
    <div class="row">
        <div class="col-12">
            <form action="<?php echo e(route('comments.store')); ?>" method="post" class="mb-4">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="topic_id" value="<?php echo e($topic->id ?? ''); ?>">
                <div class="form-group">
                    <label for="comment">Comment</label>
                    <textarea name="comment" class="form-control" placeholder="Write your comment here..." id="" cols="4" rows="4"></textarea>
                </div>
                <button class="btn btn-primary">Comment</button>
            </form>
        </div>
        <div class="col-12">
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel-7-mission-master\resources\views/topic/form.blade.php ENDPATH**/ ?>