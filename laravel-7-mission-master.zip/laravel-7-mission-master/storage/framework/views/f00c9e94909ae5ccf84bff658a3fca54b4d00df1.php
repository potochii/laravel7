<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="mb-2 text-right">
                <?php if(session()->has('save_status')): ?>
                <div class="alert alert-<?php echo e(session()->get('save_status')['status']); ?>">
                    <?php echo e(session()->get('save_status')['message']); ?>

                </div>
                <?php endif; ?>
                <?php   $userID = Auth::user()->id; ?>
                <a class="btn btn-success" href="<?php echo e(route('topics.create')); ?>">New Topic</a>
            </div>
            <table class="table table-bordered bg-white table-hover">
                <thead>
                    <tr>
                       
                        <th>no.</th>
                        <th></th>
                        <th>ID</th>
                        <th>Topic</th>
                        <th>Created By</th>
                        <th>Created At</th>
                        <th>Comment</th>
                    </tr>
                   
                </thead>
                <tbody> <?php ($i=0); ?> 
                    <?php $__empty_1 = true; $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php ($i++); ?>
                    <tr>
                        <td><?php echo e($i); ?></td>
                      
                        <td></td>
                        <td><?php echo e($topic->id); ?></td>
                        <td>
                            <a href="<?php echo e(route('topics.edit', $topic->id)); ?>"><?php echo e($topic->title); ?></a>
                        </td>
                        <td><?php echo e($topic->user->name); ?></td>
                        <td><?php echo e($topic->created_at); ?></td>
                        <?php ($i=0); ?>
                        <?php $__currentLoopData = $ments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        <?php if($topic->id==$row->topic_id): ?>  
                        
                        <?php ($i++); ?>
                        <?php endif; ?>
                       
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($i); ?></td>
                        
                       
                    </tr>

                    <tr>
                        <th></th>
                        <th>Comments </th>
                      
                   
                       
                         <td>
                         <?php $__currentLoopData = $ments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            
                         <?php if($topic->id==$row->topic_id): ?>   
                         <?php echo e($row->user->name); ?> <?php echo e($row->created_at); ?>  
                      

                         <?php if($userID==$row->user_id): ?>
                         <a style="color:Tomato;"href="<?php echo e(url('delete/'.$row->id)); ?>">delete</a>
                        <?php endif; ?>
                         <br>
                             <?php echo e($row->comment); ?>

                              <br>
                              <br>
                        <?php endif; ?>
                     
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </td>
                     </tr>
                     
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5">No topic found</td>
                    </tr>
                    <?php endif; ?>

                     
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel-7-mission-master\resources\views/home.blade.php ENDPATH**/ ?>